package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

import java.util.Comparator;

public class ObjectComparator implements Comparator {
	// The following function is a placeholder for control initialization.
	// You should call this function from a constructor or initialization function.
	void vcInit() {
		//{{INIT_CONTROLS
		//}}
	}

	public int compare(Object a, Object b) {
		// The test for numbers will not be needed in JDK1.2
		// because Numbers will be comparable.
		if ((a != null) && (b != null) && (a instanceof Comparable) && (b instanceof Comparable))
			return ((Comparable) a).compareTo(b);
		else if ((a instanceof Number) && (b instanceof Number)) {
			double aval = ((Number) a).doubleValue();
			double bval = ((Number) b).doubleValue();
			return (aval == bval) ? 0 : ((aval < bval) ? -1 : 1);
		} else
			throw new ClassCastException();
	}

	//{{DECLARE_CONTROLS
	//}}
}