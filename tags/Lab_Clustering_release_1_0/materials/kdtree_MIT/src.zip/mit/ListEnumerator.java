package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

/*
    This implements an enumerator for Lisp-like Lists, which are implemented
    as linked Conses.  The only possibly controversial item is that the end
    of a list is marked by a non-Cons, not necessarily by null.  Throws
    NoSuchElementException if one tries to nextElement beyond the end.
    
    We deliberately do not try to enforce concern about interaction between
    operation of this enumerator and modifications of the underlying list.
    Caveat emptor!
    */

public class ListEnumerator implements java.util.Enumeration {

	Cons currentCons;

	ListEnumerator(Cons c) {
		Object currentCons = c;
	}

	@Override
	public boolean hasMoreElements() {
		return (currentCons != null && currentCons instanceof Cons);
	}

	@Override
	public Object nextElement() {
		if (currentCons != null && currentCons instanceof Cons) {
			Object answer = (currentCons).car();
			currentCons = (Cons) (currentCons).cdr();
			return answer;
		}
		throw new java.util.NoSuchElementException();
	}
}