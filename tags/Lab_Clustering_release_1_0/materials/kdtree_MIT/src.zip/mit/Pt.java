package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

/*
    Pt's are like Java's Points, but store their x and y component values
    as floats rather than ints.
    
    */

public class Pt implements Comparable {
	// A Pt consists only of its x and y coordinates:
	public double x;
	public double y;

	// It may be constructed from a pair of floats, a pair of ints,
	// or another Pt.
	public Pt(double xin, double yin) {
		x = xin;
		y = yin;
	}

	public Pt(int xin, int yin) {
		x = xin;
		y = yin;
	}

	public Pt(Pt p) {
		x = p.x;
		y = p.y;
	}

	public Pt() {
		x = 0.0;
		y = 0.0;
	}

	// Coordinates may be extracted either by reference to the public
	// variables x and y or by the functions ptx and pty.
	public double ptx() {
		return x;
	}

	public double pty() {
		return y;
	}

	// Standard methods for Pts include equals and toString:
	public boolean equals(Pt p) {
		return (x == p.x && y == p.y);
	}

	@Override
	public String toString() {
		return ("(" + x + "," + y + ")");
	}

	// Translate destructively modifies a Pt by x and y increments
	public void translate(double dx, double dy) {
		x = +dx;
		y = +dy;
	}

	// Points may be added and subtracted
	public Pt PtPlus(Pt p) {
		return new Pt(x + p.x, y + p.y);
	}

	public Pt PtMinus(Pt p) {
		return new Pt(x - p.x, y - p.y);
	}

	// For various geometric algorithms, it is useful to define orderings
	// on Pts.  PtLess orders Pts lexicographically by x and y coordinates.
	// PtLessY orders lexicographically by y and x.
	public boolean PtLess(Pt p) {
		return (x < p.x || (x == p.x) && (y < p.y));
	}

	public boolean PtLessY(Pt p) {
		return (y < p.y || (y == p.y) && (x < p.x));
	}

	// Pts may be used to represent vectors from the origin to the coordinates
	// of the Pt.  In this representation, we may define the length of a pt,
	// the distance between two of them, and the cross and dot products.

	public Pt scale(double scaleFactor) {
		return new Pt(x * scaleFactor, y * scaleFactor);
	}

	public double length() {
		// length from origin to this point
		return Math.sqrt(x * x + y * y);
	}

	public double dist(Pt p) {
		return PtMinus(p).length();
	}

	public double dotProduct(Pt p) {
		return (x * p.x + y * p.y);
	}

	public double crossProduct(Pt p) {
		return (x * p.y - y * p.x);
	}

	public int compareTo(Object o) {
		if ((o != null) && (o instanceof Pt))
			return (equals((Pt) o) ? 0 : ((PtLess((Pt) o)) ? -1 : 1));
		else
			throw new ClassCastException();
	}

}
