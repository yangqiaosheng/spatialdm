package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

import java.util.Comparator;

public class PtComparatorY implements Comparator {

	public int compare(Object a, Object b) {
		if ((a != null) && (b != null) && (a instanceof Pt) && (b instanceof Pt))
			return (((Pt) a).equals((Pt) b)) ? 0 : (((Pt) a).PtLessY((Pt) b)) ? -1 : 1;
		else
			throw new ClassCastException();
	}
}