package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

public class Seg {
	Pt start;
	Pt end;

	public Seg(Pt s, Pt e) {
		start = s;
		end = e;
	}

	// Inverse returns the segment running from end to start
	public Seg inverse() {
		return new Seg(end, start);
	}

	public double length() {
		return segPt().length();
	}

	public Pt segPt() {
		return (end.PtMinus(start));
	}

	// Computes twice the area of the triangle formed by the endpoints of
	// the Seg and the Pt.  (Equals the area of parallelogram.)
	public double triangleArea2(Pt p) {
		return Math.abs(p.x * start.y + p.y * end.x + start.x * end.y - end.x * start.y - end.y * p.x - start.x * p.y);
	}

	// Computes distance from the line extending Seg to Pt.
	public double dist(Pt p) {
		double len = length();
		if (len == 0.0)
			return 0.0;
		return (triangleArea2(p) / len);
	}

	public double crossProduct(Seg s) {
		return segPt().crossProduct(s.segPt());
	}

	public double dotProduct(Seg s) {
		return segPt().dotProduct(s.segPt());
	}

	public boolean intersects(Seg s) {
		Region it = new Region(this);
		Region sr = new Region(s);
		return (it.intersects(sr));
	}

	//  This tells whether the Pt p is "next to" the line or off the end of 
	//  it.  True iff the perpendicular dropped from the Pt to the Seg lies 
	//  within the Seg.  We use dot products to find out.
	public boolean beside(Pt p) {
		return (dotProduct(new Seg(start, p)) >= 0) && (inverse().dotProduct(new Seg(end, p)) >= 0);
	}

	//  Computes the distance from a point to a line segment.
	// If the point is beside the segment, then it's just dist;
	// Otherwise, it's distance to nearest endpoint.
	public double closeDist(Pt p) {
		if (beside(p))
			return dist(p);
		return Math.min(start.dist(p), end.dist(p));
	}

}