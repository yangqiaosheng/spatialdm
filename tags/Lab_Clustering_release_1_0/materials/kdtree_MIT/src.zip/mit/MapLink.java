package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

/*
Components defined for links:
1.  start node id
2.  end node id
3.  "LEN"                 (float,  length (supposedly))
4.  "ZV1"                 (int,  lowest altitude on link)
5.  "RST"                 (int,  road surface type (supposedly))
6.  "EXS"                 (int,   road existence (supposedly))
         */

public class MapLink extends Seg {
	//MapNode start;
	//MapNode end;
	double length;
	double lowest;
	int surface;
	int exists;

	public static double lengthNull = -32768.0;
	public static double lowestNull = -32768.0;
	public static int surfaceNull = -32768;
	public static int existsNull = -32768;

	public MapLink(Map m, String s, String e, double len, double low, int surf, int exist) {
		this(m, MapNode.calcId(s), MapNode.calcId(e), len, low, surf, exist);
	}

	public MapLink(Map m, int s, int e, double len, double low, int surf, int exist) {
		this(m, m.getNode(s), m.getNode(e), len, low, surf, exist);
	}

	public MapLink(Map m, MapNode s, MapNode e, double len, double low, int surf, int exist) {
		super(s, e);
		length = len;
		lowest = low;
		surface = surf;
		exists = exist;
		s.links.addElement(this);
		e.links.addElement(this);
	}

	@Override
	public String toString() {
		if ((start instanceof MapNode) && (end instanceof MapNode)) {
			MapNode sn = (MapNode) start;
			MapNode en = (MapNode) end;
			int si = sn.identity;
			int ei = en.identity;
			return "<Seg " + si + "--" + ei + ">";
		}
		return "<Seg " + start.toString() + "--" + end.toString() + ">";
	}

}