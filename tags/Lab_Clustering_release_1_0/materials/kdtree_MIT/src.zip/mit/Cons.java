package kdtree.mit;

import java.util.Comparator;
import java.util.Enumeration;
import java.util.Vector;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

/*  Implementation of Lisp-like lists.
    This is a very simple, straightforward implementation of Lisp's
    cons/car/cdr operators to support list processing.  Far more
    sophisticated versions of lists exist as part of Java's Collections,
    but this is useful for translating Lisp code.  It is also relatively
    space and time efficient because it minimizes the costs of guarantees
    made by collections.
    
    Cons is the primitive constructor.  Lists can be made from other 
    enumerable structures and arrays (I've only implemented those for
    Object, but others are straightforward, though each element of a Cons
    must be encapsulated as an Object).  E.g., Cons.List(vector_of_objects);
*/

public class Cons {

	Object _car;
	Object _cdr;

	//static int counter = 0;

	public Cons(Object theCar, Object theCdr) {
		_car = theCar;
		_cdr = theCdr;
		//counter++;
		//if (counter%10000 == 0) System.out.println(counter + " conses.");
	}

	public Object car() {
		return _car;
	}

	public Object cdr() {
		return _cdr;
	}

	public void setCar(Object newValue) {
		_car = newValue;
	}

	public void setCdr(Object newValue) {
		_cdr = newValue;
	}

	public Cons reverse() {
		Cons answer = null;
		for (Cons l = this; l != null; l = (Cons) l.cdr()) {
			answer = new Cons(l.car(), answer);
		}
		return answer;
	}

	public Cons nreverse() {
		Cons answer = null;
		Cons l = this;
		Cons next = l;
		for (; next != null; l = next) {
			next = (Cons) l.cdr();
			l.setCdr(answer);
			answer = l;
		}
		return answer;
	}

	public int length() {
		// assumes that length can be represented by an int.
		int answer = 0;
		Cons l = this;
		for (; l instanceof Cons; l = (Cons) l.cdr()) {
			answer = answer + 1;
		}
		return answer;
	}

	public Cons sort() {
		return new ListSorter().sort(this);
	}

	public Cons sort(Comparator cmp) {
		return new ListSorter().sort(this);
	}

	@Override
	public String toString() {
		String answer = "(" + _car.toString();
		Object restl = _cdr;
		for (; restl instanceof Cons; restl = ((Cons) restl).cdr()) {
			if (((Cons) restl).car() == null) {
				answer = answer + " ()";
			} else {
				answer = answer + " " + ((Cons) restl).car().toString();
			}
		}
		if (restl != null) {
			answer = answer + " . " + restl.toString();
		}
		answer = answer + ")";
		return answer;
	}

	public Enumeration elements() {
		return new ListEnumerator(this);
	}

	// Factory methods:

	public static Cons List(Vector v) {
		Cons answer = null;
		for (Enumeration e = v.elements(); e.hasMoreElements();) {
			answer = new Cons(e.nextElement(), answer);
		}
		return answer.nreverse();
	}

	// Copies only non-null elements of v
	public static Cons ListNonNull(Vector v) {
		Cons answer = null;
		for (Enumeration e = v.elements(); e.hasMoreElements();) {
			Object n = e.nextElement();
			if (n != null) {
				answer = new Cons(n, answer);
			}
		}
		return answer.nreverse();
	}

	public static Cons List(Object[] o) {
		Cons answer = null;
		for (Object element : o) {
			answer = new Cons(element, answer);
		}
		return answer.nreverse();
	}

	//{{DECLARE_CONTROLS
	//}}
}
