package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

//import java.util.Vector;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;

public class Map {
	Vector nodes;
	Vector links;
	KdTree theKdTree;
	double avgLinkLength;
	double minLinkLength;
	double maxLinkLength;
	public Region mapRegion; // Region contains map data

	public double lastDistance; // last dist for closestLink

	public static double km_per_degree = 110.0;

	// This is a debugging crock just to reduce the size of the KdTree so it can be built
	// while running in the debugger.
	public Region ignoreBounds = null;

	//public Region ignoreBounds = new Region(55.5, 56.0, 27.0, 27.5);

	public Map(String NodesFileName, String LinksFileName) {
		nodes = new Vector(10000, 10000);
		links = new Vector(10000, 10000);
		BufferedReader bf = null;
		try {
			bf = new BufferedReader(new InputStreamReader(new FileInputStream(new File(NodesFileName))));
		} catch (FileNotFoundException e) {
			System.out.println("Error: " + e);
		}
		;

		String line = "";
		try {
			line = bf.readLine();
		} catch (IOException e) {
			System.out.println("Empty Nodes file: " + this + ": " + e);
		}
		do {
			addNodeLine(line);
			//if (nodes.size()%100 == 0)
			//System.out.print(".");
			try {
				line = bf.readLine();
			} catch (IOException e) {
				line = null;
			}
		} while ((line != null) && (!line.equals("")));
		//System.out.println("Read " + nodes.size() + " nodes.");
		try {
			bf = new BufferedReader(new InputStreamReader(new FileInputStream(new File(LinksFileName))));
		} catch (FileNotFoundException e) {
			System.out.println("Error: " + e);
		}
		;

		line = "";
		try {
			line = bf.readLine();
		} catch (IOException e) {
			System.out.println("Empty Links file: " + this + ": " + e);
		}
		do {
			addLinkLine(line);
			//if (links.size()%100 == 0)
			//System.out.print(".");
			try {
				line = bf.readLine();
			} catch (IOException e) {
				line = null;
			}
		} while ((line != null) && (!line.equals("")));
		//System.out.println("Read " + links.size() + " links.");

		//  Other initializations:

		//  Compute bounds for the map:
		{
			double xmin = ((MapNode) nodes.elementAt(0)).ptx();
			double xmax = xmin;
			double ymin = ((MapNode) nodes.elementAt(0)).pty();
			double ymax = ymin;
			for (int i = nodes.size() - 1; i > 0; i--) {
				MapNode n = (MapNode) nodes.elementAt(i);
				if (n != null) {
					double x = n.ptx();
					double y = n.pty();
					if (x < xmin) {
						xmin = x;
					} else if (x > xmax) {
						xmax = x;
					}
					if (y < ymin) {
						ymin = y;
					} else if (y > ymax) {
						ymax = y;
					}
				}
			}
			mapRegion = new Region(xmin, xmax, ymin, ymax);
		}
		//System.out.println("Map bounds: " + mapRegion);

		// While debugging, I can't build the 35,000 node KdTree because we run out of Cons memory!!!
		// UGHHHH!
		// Therefore, we flush all nodes that fall outside ignoreBounds.
		if (ignoreBounds != null) {
			Vector allNodes = nodes;
			nodes = new Vector(2000, 2000);
			for (Enumeration e = allNodes.elements(); e.hasMoreElements();) {
				MapNode n = (MapNode) e.nextElement();
				if (n != null && ignoreBounds.contains(n)) {
					nodes.addElement(n);
				}
			}
		}

		// Compute the KdTree for nodes in the map:
		theKdTree = (KdTree) KdTree.make(nodes);

		//  Compute the average link segments length, as a heuristic for the 
		// size of range that should be searched when looking for the closest 
		// link. 
		minLinkLength = ((MapLink) links.elementAt(0)).length();
		maxLinkLength = minLinkLength;

		{
			double totalLinkLength = 0.0;
			for (Enumeration e = links.elements(); e.hasMoreElements();) {
				MapLink ll = (MapLink) e.nextElement();
				double l = ll.length();
				totalLinkLength = totalLinkLength + l;
				if (l < minLinkLength) {
					minLinkLength = l;
				} else if (l > maxLinkLength) {
					maxLinkLength = l;
				}
			}
			avgLinkLength = totalLinkLength / links.size();
		}
		//System.out.println("Link lengths:");
		//System.out.println("Average: " + avgLinkLength + ", Min: "
		//                   + minLinkLength + ", Max: " + maxLinkLength);

	}

	private void addNodeLine(String line) {
		Vector nodeSpec = Map.parseLine(line);
		if (nodeSpec.size() != 3) {
			System.out.println("Error on bad node spec: " + nodeSpec.toString());
		} else {
			double lat = (new Double((String) nodeSpec.elementAt(1))).doubleValue();
			double lon = (new Double((String) nodeSpec.elementAt(2))).doubleValue();
			MapNode n = new MapNode((String) nodeSpec.elementAt(0), lat, lon);
			nodes.addElement(n);
		}
	}

	private void addLinkLine(String line) {
		Vector linkSpec = Map.parseLine(line);
		if (linkSpec.size() != 6) {
			System.out.println("Error on bad link spec: " + linkSpec.toString());
		} else {
			int sid = MapNode.calcId((String) linkSpec.elementAt(0));
			int eid = MapNode.calcId((String) linkSpec.elementAt(1));
			MapNode sn = getNode(sid);
			MapNode en = getNode(eid);
			if (sn == null || en == null) {
				System.out.println("Defining bad link from " + sid + " to " + eid);
			}
			//if (sn != null && !ignoreBounds.contains(sn)) sn = null;
			//if (en != null && !ignoreBounds.contains(en)) en = null;
			//if (sn != null && en != null)
			links.addElement(new MapLink(this, sn, en, (new Double((String) linkSpec.elementAt(2))).doubleValue(), //len
					(new Double((String) linkSpec.elementAt(3))).doubleValue(), //low
					(new Integer((String) linkSpec.elementAt(4))).intValue(), //surf
					(new Integer((String) linkSpec.elementAt(5))).intValue())); //ex
		}
	}

	private static Vector parseLine(String line) {
		Vector sv = new Vector(6); // We cheat to know that 6 is the right size!
		StringTokenizer st = new StringTokenizer(line, " \"\t\n\r");
		while (st.hasMoreTokens()) {
			sv.addElement(st.nextToken());
		}
		return sv;
	}

	public MapNode getNode(int id) {
		if (id > nodes.size())
			return null;
		return (MapNode) nodes.elementAt(id - 1);
	}

	public void putNode(MapNode n) {
		int i = n.identity;
		if (i >= nodes.size()) {
			nodes.setSize(i);
		}
		nodes.setElementAt(n, i - 1);
	}

	/*  closestLink uses the KdTree to compute a set of nodes close to the 
	    prope Pt.  It then considers each of the links that start or end at 
	    those nodes to see which is closest.  This is heuristic and works 
	    only if links are short on the scale of avgLinkLength; otherwise, it 
	    may be possible for a long line segment to come close to a point even 
	    if neither of its endpoints is close.  As a side-effect, this sets
	    lastDistance to the actual distance of point to segment, in case the
	    caller needs this information.
	*/
	public MapLink closestLink(Pt p) {
		double x = p.ptx();
		double y = p.pty();
		double d = avgLinkLength;
		Vector close;
		// Keep trying with larger regions until we get something
		do {
			d = 2 * d;
			Region r = new Region(x - d, x + d, y - d, y + d);
			close = theKdTree.findPts(r);
		} while (close.size() == 0);
		// close now contains a list of Nodes close to p;
		// find link that is closest:
		MapLink c = null;
		lastDistance = 100 * d; // be sure we find something smaller!
		MapNode node;
		MapLink link;
		double distance;
		for (Enumeration e = close.elements(); e.hasMoreElements();) {
			node = (MapNode) e.nextElement();
			for (Enumeration f = node.links.elements(); f.hasMoreElements();) {
				link = (MapLink) f.nextElement();
				distance = link.closeDist(p);
				if (distance < lastDistance) {
					lastDistance = distance;
					c = link;
				}
			}
		}
		return c; // recall: lastDistance also meaningful;
					// ... wishing for Lisp's multiple-value returns
	}
}
