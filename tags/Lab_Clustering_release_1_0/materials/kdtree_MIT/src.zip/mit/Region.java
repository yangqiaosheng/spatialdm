package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

public class Region {
	public double xl;
	public double xh;
	public double yl;
	public double yh;

	public Region(double xlow, double xhigh, double ylow, double yhigh) {
		xl = xlow;
		xh = xhigh;
		yl = ylow;
		yh = yhigh;
	};

	public Region(Pt ll, Pt ur) {
		xl = Math.min(ll.x, ur.x);
		xh = Math.max(ll.x, ur.x);
		yl = Math.min(ll.y, ur.y);
		yh = Math.max(ll.y, ur.y);
	};

	public Region(Seg s) {
		this(s.start, s.end);
	};

	public boolean intersects(Region r) {
		return ((xh >= r.xl) && (r.xh >= xl) && (yh >= r.yl) && (r.yh >= yl));
	}

	//  Region contains p; Region is open at bottom, closed at top of x and y.
	//  This is certainly not generally true, and should be re-thought.
	public boolean contains(Pt p) {
		double x = p.ptx();
		double y = p.pty();
		return (xl < x && x <= xh && yl < y && y <= yh);
	}

	@Override
	public String toString() {
		return "[" + xl + "," + xh + "]x[" + yl + "," + yh + "]";
	}
}