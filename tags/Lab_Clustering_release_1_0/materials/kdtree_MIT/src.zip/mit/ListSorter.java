package kdtree.mit;

/*	Copyright (c) 1998 by Peter Szolovits and Massachusetts Institute of Technology.

This code was developed as part of the Maita project at the Clinical Decision 
Making Group of the MIT Laboratory for Computer Science, under funding from
the HPKB (High Performance Knowledge Base) program of DARPA.

Permission is granted to use this code on the conditions that:
 1.  There is no warranty, implied or explicit, that this code is correct or
     does anything useful.  Therefore the user will not hold above copyright
     holders in any way responsible or liable for losses resulting from using
     this code or causing it to be used.
 2.  This copyright notice is retained on any copies made of this code.
 3.  Alterations may be made but must be identified as derived from this work.
 4.  No derivative software substantially incorporating this code may be sold
     for profit without explicit permission of the above copyright holders.
*/

import java.util.Comparator;

public class ListSorter {

	/*  Implementation of the MACLISP sort (destructive) algorithm.
	    This must be used in the form
	        Cons ans = sort(list);
	    because the Cons that is the initial value of list may become
	    some interior element of the resulting list.
	    */
	private Cons c;
	private Cons f;
	private Comparator comparator;

	public ListSorter() {
		this(new ObjectComparator());
	}

	public ListSorter(Comparator cmp) {
		c = null;
		f = null;
		comparator = cmp;
	}

	public synchronized Cons sort(Cons l) {
		// must be synchronized because it retains state in c and f;
		// Because Java has no nested methods, I am keeping these as
		// class variables on Cons (ugh!)
		c = l;
		f = new Cons(null, null);
		return sortTop(-1, null);
	}

	private Cons sortTop(int level, Cons partial) {
		return (c == null) ? partial : sortTop(level + 1, mmerge(partial, mprefx(level)));
	}

	private Cons mprefx(int tt) {
		if (c == null)
			return null;
		else if (tt < 1)
			return popc();
		else
			return mmerge(mprefx(tt - 1), mprefx(tt - 1));
	}

	private Cons popc() {
		// pops one list element off the front of c;
		Cons answer = c;
		c = (Cons) c.cdr();
		answer.setCdr(null);
		return answer;
	}

	/* Merges two sorted lists a and b*/
	private Cons mmerge(Cons a, Cons b) {
		Cons r = f;
		Cons answer = null;
		while (true) {
			if (a == null) {
				r.setCdr(b);
				answer = (Cons) f.cdr();
				break;
			} else if (b == null) {
				r.setCdr(a);
				answer = (Cons) f.cdr();
				break;
			}
			if (comparator.compare(a.car(), b.car()) > 0) {
				// if a > b, then add b's first element
				Cons oldR = r;
				r = b;
				oldR.setCdr(r);
				b = (Cons) b.cdr();
			} else {
				Cons oldR = r;
				r = a;
				oldR.setCdr(r);
				a = (Cons) a.cdr();
			}
		}
		return answer;
	}
}