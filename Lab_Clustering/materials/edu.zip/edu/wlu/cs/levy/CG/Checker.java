package edu.wlu.cs.levy.CG;

public interface Checker<T> {
    public boolean usable(T v);
}
